package com.dbteam.application;

public class FindSearchDog {


        private String value;   //검색어


        public FindSearchDog(String value) {
            this.value = value;
        }



        @Override
        public String toString() {
            return "SearchDogKind{" +
                    "value='" + value + '\'' +
                    '}';
        }

    }

